-- 
-- This SQL dump created by P.A.S. v.4.1.1b
-- 
-- Started at 2019-12-28 13:20:48 UTC

CREATE TABLE `db_invcompetition_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(10) NOT NULL,
  `user_id` int(11) NOT NULL,
  `points` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=cp1251;

INSERT INTO `db_invcompetition_users` VALUES
('1','Администра','1','0'),
('2','VIP199120','87','0'),
('3','rurik','90','0'),
('4','sakhrus','100','0'),
('5','ladamira','110','0'),
('6','aleks59','113','0'),
('7','Ilias74766','140','0'),
('8','chyzhyk170','154','0'),
('9','Buran66','179','0'),
('10','alex','191','0'),
('11','vitalik001','134','0'),
('12','Yla93','216','0'),
('13','P100017575','242','0'),
('14','Kozmanov','259','0'),
('15','yur2243252','332','0'),
('16','Olia42','329','0'),
('17','olegon58','201','0'),
('18','Telke','335','0'),
('19','zuma123','401','0'),
('20','zaceba','355','0'),
('21','bassnya','444','0'),
('22','dreypil','533','0'),
('23','sdfffdd','544','0'),
('24','firon36','593','0'),
('25','Shurshik','594','0'),
('26','vasek1981','651','0'),
('27','lis5310','466','0'),
('28','sachok','638','0');
-- Finished at 2019-12-28 13:20:48 UTC