-- 
-- This SQL dump created by P.A.S. v.4.1.1b
-- 
-- Started at 2019-12-28 13:20:48 UTC

CREATE TABLE `db_competition_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(10) NOT NULL,
  `user_id` int(11) NOT NULL,
  `points` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=cp1251;

INSERT INTO `db_competition_users` VALUES
('1','Probka','68','1'),
('2','Telke','335','2'),
('3','alex','191','10'),
('4','РђРґРјРёРЅ','1','10');
-- Finished at 2019-12-28 13:20:48 UTC