-- 
-- This SQL dump created by P.A.S. v.4.1.1b
-- 
-- Started at 2019-12-28 13:20:48 UTC

CREATE TABLE `db_sender` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `mess` text NOT NULL,
  `page` int(5) NOT NULL DEFAULT '0',
  `sended` int(7) NOT NULL DEFAULT '0',
  `status` int(1) NOT NULL DEFAULT '0',
  `date_add` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=cp1251;

INSERT INTO `db_sender` VALUES
('1','Обновление РАЗДАЧИ','Здравствуйте &quot;{!USER!}&quot;\r\nПриглашаем Вас оценить обновления!\r\n\r\nСегодня произвели ряд мелких обновлений проекта, касающихся функциональности! \r\n\r\nЕще обновили РАЗДАЧУ, теперь можно получать раздачу значительно больше! \r\nСмотрите подробнее - https://black-money.ru/','10','484','1','1575290933');
-- Finished at 2019-12-28 13:20:48 UTC