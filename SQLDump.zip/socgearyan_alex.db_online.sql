-- 
-- This SQL dump created by P.A.S. v.4.1.1b
-- 
-- Started at 2019-12-28 13:20:48 UTC

CREATE TABLE `db_online` (
  `id` int(11) NOT NULL,
  `ip` varchar(55) NOT NULL,
  `date` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;
-- Finished at 2019-12-28 13:20:48 UTC